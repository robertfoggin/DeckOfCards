﻿using System;

namespace DeckOfCards
{
    public class Example
    {
        static void Main(string[] args)
        {
            
            deck newDeck = new deck(); //new deck class where a the new deck gets assigned into
            newDeck.Shuffle(); //shuffles the new deck
            
            //whilst the statement is true (always) it will ask the user if they want to pick up another card from the shuffled cards.
            bool running = true;
            while (running == true)
            {
                Console.WriteLine("Your Card is: {0}", newDeck.deal());
                Console.WriteLine("Press Enter to get another card");
                Console.ReadLine();
                
            }
            

         











        }
    }
}
