﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeckOfCards
{
    public class card
    {
        //Creates two private string variables. face = Ace, Two, Three, Four etc.
        // suit = Hearts, Clubs, Diamonds and Spades
        private string face;
        private string suit;

        public card(string cardFace, string cardSuit)
        {
            //initializes the face and suit of card
            face = cardFace;
            suit = cardSuit;
        }

        //overrides two string function which every class has and provides own definition of two string function
        public override string ToString()
        {
            //returns string representation of card
            return "The " + face + " of " + suit;
        }
    }
}
