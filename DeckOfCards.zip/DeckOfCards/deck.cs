﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DeckOfCards
{
    public class deck
    {
        private card[] deck1; //private array of cards
        private int currentCard; //keeps track of where we are in the current deck
        private const int NUMBER_OF_CARDS = 52;
        private Random randomNumber; 

        public deck()
            //Arrays of faces and suits
        {
            string[] faces = {"Ace", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight",
            "Nine", "Ten", "Jack", "Queen", "King"};

            string[] suits = { "Hearts", "Clubs", "Diamonds", "Spades" };
            //Creates a new deck with the card class with the number of cards in it (52)
            deck1 = new card[NUMBER_OF_CARDS];
            currentCard = 0;
            randomNumber = new Random(); //creates random number generator
            //Populates the deck
            for (int count = 0; count < deck1.Length; count++)
                deck1[count] = new card(faces[count % 11], suits[count / 13]);


        }

        //Shuffles every card in the deck via for loop
        public void Shuffle()
        {
            currentCard = 0;
            //For each card from 0 to 51, picks another random card and swaps them
            for (int first = 0; first < deck1.Length; first++)
            {
                //selects random number between 0 and 51
                int second = randomNumber.Next(NUMBER_OF_CARDS);
                //Swaps current card with the randomly selected one
                card temp = deck1[first];
                deck1[first] = deck1[second];
                deck1[second] = temp;
            }
        }

        public card deal()
        {
            
            if (currentCard < deck1.Length) //makes sure that the currentCard is within bounds of the deck length which is 52
                return deck1[currentCard++]; //return the next card in the deck
            else
                return null;
        }


    }
}
